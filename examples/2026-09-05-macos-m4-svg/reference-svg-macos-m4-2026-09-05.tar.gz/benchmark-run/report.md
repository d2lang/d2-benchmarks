# Diagram CLI benchmark

Run `reference-svg-macos-m4` · status **complete**

800 successful measured attempts / 800 expected; 0 failures, 0 missing measurements. 120 excluded warm-ups (0 failed).

[Interactive report](index.html) · [CSV](summary.csv) · [Complete statistics](summary.json) · [Run metadata](run.json) · [Raw attempts](raw.jsonl)

0 jobs produced more than one measured output hash. Changing bytes can reflect layout, identifiers or metadata; hashes alone do not explain the cause. Asset sizes describe the verified retained final output, not an average over changing outputs.

## Method and uncertainty

Percentile 95% bootstrap intervals resample complete measured round indices, using the same indices across tools and fixtures. Every fixture remains in the fixed corpus. These intervals describe within-run sampling noise, not uncertainty across machines, sessions, background loads, or populations of graphs. No outliers are removed. Incomplete jobs show descriptive successful-attempt samples only.

Medians use all successful measured attempts, excluding warm-ups. 20 measurements and 3 warm-ups were planned per job. Bootstrap iterations: 2000; deterministic seed: 4884683596465977979.

Fresh-process CLI time includes startup, parsing, layout, rendering and output writing. It is not isolated layout-engine time. Image sizes include actual renderer metadata and font/resource choices. Gzip-9 is a separate generic compression measurement, most useful for SVG; the PNG file is already compressed. Equal PNG density does not imply equal pixels or equal styling. These D2-authored diagrams are a fixed corpus, not a random sample of graph workloads.

## svg

10 fixed fixtures; 800 successes / 800 expected measurements; 0 failures.

Ratios are `d2-dagre median / tool median`, geometrically averaged over matched fixtures. Above 1 means the tool is faster than the baseline. The baseline interval is exactly 1 because it is compared with itself.

| Tool | Geomean median (ms) | Baseline / tool | 95% interval | Raw bytes | Gzip-9 bytes | PNG pixels |
|---|---:|---:|---:|---:|---:|---:|
| D2 / Dagre | 30.60 | 1.00 | 1.00–1.00 | 571,234 | 201,206 | — |
| Graphviz / dot | 77.47 | 0.39 | 0.39–0.42 | 328,419 | 61,394 | — |
| Mermaid / Dagre | 426.81 | 0.07 | 0.07–0.08 | 656,710 | 94,024 | — |
| PlantUML / Graphviz | 932.47 | 0.03 | 0.03–0.04 | 355,876 | 90,871 | — |

## Per-job observations

Incomplete rows retain all successful observations for diagnosis; their conditional medians are not eligible for aggregate rankings. Intervals and ranges describe milliseconds.

| Diagram | Tool | Output | Success / expected | Failed | Missing | Median | 95% interval | Min–max | Output hashes | Eligible |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| Fulcro RAD architecture | D2 / Dagre | svg | 20/20 | 0 | 0 | 26.88 | 26.34–30.94 | 25.27–43.85 | 1 | yes |
| Fulcro RAD architecture | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 398.61 | 393.10–416.23 | 382.48–429.90 | 1 | yes |
| Fulcro RAD architecture | Graphviz / dot | svg | 20/20 | 0 | 0 | 75.81 | 75.33–77.33 | 73.17–92.07 | 1 | yes |
| Fulcro RAD architecture | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 916.96 | 912.03–922.88 | 899.07–943.49 | 1 | yes |
| Jupyter AWS EKS infrastructure | D2 / Dagre | svg | 20/20 | 0 | 0 | 22.04 | 20.89–23.71 | 20.19–36.22 | 1 | yes |
| Jupyter AWS EKS infrastructure | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 392.25 | 385.74–401.96 | 379.12–429.86 | 1 | yes |
| Jupyter AWS EKS infrastructure | Graphviz / dot | svg | 20/20 | 0 | 0 | 76.96 | 75.62–78.06 | 73.35–93.84 | 1 | yes |
| Jupyter AWS EKS infrastructure | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 921.74 | 913.27–930.23 | 886.55–943.60 | 1 | yes |
| Jupyter Kubernetes OIDC access flow | D2 / Dagre | svg | 20/20 | 0 | 0 | 20.33 | 19.72–23.11 | 19.19–35.58 | 1 | yes |
| Jupyter Kubernetes OIDC access flow | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 424.98 | 417.75–434.90 | 409.62–456.33 | 1 | yes |
| Jupyter Kubernetes OIDC access flow | Graphviz / dot | svg | 20/20 | 0 | 0 | 78.02 | 77.24–87.62 | 74.43–94.21 | 1 | yes |
| Jupyter Kubernetes OIDC access flow | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 921.41 | 909.51–926.92 | 894.79–969.81 | 1 | yes |
| Ouroboros Leios simulator components | D2 / Dagre | svg | 20/20 | 0 | 0 | 23.28 | 22.72–30.11 | 22.05–39.11 | 1 | yes |
| Ouroboros Leios simulator components | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 399.18 | 397.52–407.09 | 386.99–466.33 | 1 | yes |
| Ouroboros Leios simulator components | Graphviz / dot | svg | 20/20 | 0 | 0 | 76.17 | 75.65–77.20 | 71.46–89.34 | 1 | yes |
| Ouroboros Leios simulator components | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 915.81 | 905.30–922.40 | 887.39–956.89 | 1 | yes |
| Lion Reader frontend data flow | D2 / Dagre | svg | 20/20 | 0 | 0 | 29.23 | 28.63–37.75 | 27.72–46.12 | 1 | yes |
| Lion Reader frontend data flow | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 406.60 | 402.45–427.17 | 390.83–438.67 | 1 | yes |
| Lion Reader frontend data flow | Graphviz / dot | svg | 20/20 | 0 | 0 | 75.58 | 74.24–76.08 | 70.99–93.31 | 1 | yes |
| Lion Reader frontend data flow | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 917.99 | 909.31–927.10 | 901.56–957.24 | 1 | yes |
| Mocha secure-enclave SoC | D2 / Dagre | svg | 20/20 | 0 | 0 | 31.46 | 29.30–44.89 | 28.94–47.12 | 1 | yes |
| Mocha secure-enclave SoC | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 406.02 | 403.37–415.69 | 396.72–438.94 | 1 | yes |
| Mocha secure-enclave SoC | Graphviz / dot | svg | 20/20 | 0 | 0 | 66.75 | 66.10–80.34 | 62.32–85.05 | 1 | yes |
| Mocha secure-enclave SoC | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 928.80 | 924.22–933.96 | 902.83–958.66 | 1 | yes |
| Go Queue multi-service worker architecture | D2 / Dagre | svg | 20/20 | 0 | 0 | 27.49 | 26.46–39.22 | 25.16–44.36 | 1 | yes |
| Go Queue multi-service worker architecture | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 424.02 | 416.16–430.65 | 407.12–489.94 | 1 | yes |
| Go Queue multi-service worker architecture | Graphviz / dot | svg | 20/20 | 0 | 0 | 77.39 | 75.29–81.85 | 72.13–94.39 | 1 | yes |
| Go Queue multi-service worker architecture | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 914.61 | 910.44–916.27 | 874.69–953.10 | 1 | yes |
| ROSS package overview | D2 / Dagre | svg | 20/20 | 0 | 0 | 23.85 | 23.51–24.98 | 23.06–38.53 | 1 | yes |
| ROSS package overview | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 391.86 | 385.33–396.42 | 379.81–427.37 | 1 | yes |
| ROSS package overview | Graphviz / dot | svg | 20/20 | 0 | 0 | 77.64 | 76.34–79.43 | 73.86–94.49 | 1 | yes |
| ROSS package overview | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 920.09 | 908.77–922.76 | 878.08–935.67 | 1 | yes |
| Spyre encoder inference target design | D2 / Dagre | svg | 20/20 | 0 | 0 | 33.67 | 33.15–35.38 | 31.57–47.92 | 1 | yes |
| Spyre encoder inference target design | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 448.07 | 441.24–452.51 | 438.11–482.58 | 1 | yes |
| Spyre encoder inference target design | Graphviz / dot | svg | 20/20 | 0 | 0 | 97.31 | 95.96–112.12 | 91.37–115.67 | 1 | yes |
| Spyre encoder inference target design | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 965.64 | 959.70–970.80 | 949.06–1,004.82 | 1 | yes |
| TPMJS platform architecture v1 | D2 / Dagre | svg | 20/20 | 0 | 0 | 126.38 | 121.41–138.97 | 115.97–145.67 | 1 | yes |
| TPMJS platform architecture v1 | Mermaid / Dagre | svg | 20/20 | 0 | 0 | 615.42 | 611.47–636.07 | 603.42–650.05 | 1 | yes |
| TPMJS platform architecture v1 | Graphviz / dot | svg | 20/20 | 0 | 0 | 76.18 | 74.42–77.06 | 70.50–91.93 | 1 | yes |
| TPMJS platform architecture v1 | PlantUML / Graphviz | svg | 20/20 | 0 | 0 | 1,005.69 | 1,001.09–1,018.77 | 976.58–1,034.86 | 1 | yes |

## Environment and provenance

The following metadata belongs to this run. No results from other machines or historical runs are substituted.

```json
{
  "environment": {
    "os": "Darwin",
    "os_release": "25.6.0",
    "os_version": "Darwin Kernel Version 25.6.0: Fri Jul 31 19:11:03 PDT 2026; root:xnu-12377.161.14~5/RELEASE_ARM64_T8132",
    "architecture": "arm64",
    "logical_cpus": 10,
    "python": "3.12.14",
    "cpu": "Apple M4",
    "memory_bytes": "17179869184",
    "clock": {
      "implementation": "mach_absolute_time()",
      "monotonic": true,
      "adjustable": false,
      "resolution": 4.166666666666667e-08
    },
    "background_load_controlled": false,
    "environment_note": "Fresh processes, warm filesystem caches. Runner does not change power, CPU, scheduler, or system settings.",
    "tools": {
      "d2-dagre": {
        "kind": "d2",
        "version": "v0.8.1-HEAD",
        "file_sha256": {
          "${REPO}/.tools-shell/bin/d2": "6658928af71f60d3d252d444be91b0e689cb8479e898c54950e4f7e9936752b8"
        },
        "environment_overrides": {},
        "provenance": {
          "runtime_lock_sha256": "7748932cce1f5d830f3810c4eac1fee560608db395925bc13f563704ef4c1cf1",
          "setup_platform": "osx-arm64",
          "source": "https://github.com/d2lang/d2",
          "revision": "a825194903523c4409f4df7e7f4385efacb6deeb",
          "go": "1.27.0",
          "build": "CGO_ENABLED=0 go build -trimpath -ldflags=\"-s -w\"",
          "binary_sha256": "6658928af71f60d3d252d444be91b0e689cb8479e898c54950e4f7e9936752b8"
        }
      },
      "mermaid-dagre": {
        "kind": "mermaid",
        "version": "11.17.0",
        "file_sha256": {
          "${REPO}/.tools-shell/node/node-v24.19.0-darwin-arm64/bin/node": "27db838bb204ef7c21df2931f5656e4c8fb32e6e947f363a402b49714d32b5b1",
          "${REPO}/.tools-shell/mermaid/node_modules/@mermaid-js/mermaid-cli/src/cli.js": "91736b13c07adaba94f1000c31b5679ce78cf5b86685cb0e07f0d1912d91a799",
          "${REPO}/.tools-shell/chrome/chrome-headless-shell-mac-arm64/chrome-headless-shell": "51083e7cf58ba060a0160b8f447ea04c0e9bada00c30a047259bcfe1217b82c3"
        },
        "environment_overrides": {
          "PUPPETEER_EXECUTABLE_PATH": "${REPO}/.tools-shell/chrome/chrome-headless-shell-mac-arm64/chrome-headless-shell",
          "PUPPETEER_CACHE_DIR": "${REPO}/.tools/cache/puppeteer"
        },
        "provenance": {
          "runtime_lock_sha256": "7748932cce1f5d830f3810c4eac1fee560608db395925bc13f563704ef4c1cf1",
          "setup_platform": "osx-arm64",
          "node": "24.19.0",
          "mermaid_cli": "11.17.0",
          "mermaid": "11.17.2",
          "puppeteer": "25.10.0",
          "chrome": "152.0.7977.75",
          "chrome_archive_sha256": "9f599a775de391846eac644b50ed885474e27769ba73096e15507e732e04edef",
          "browser_variant": "chrome-headless-shell",
          "headless_mode": "shell",
          "npm_lock_sha256": "0d34cbf7233929062f2ebbb3212d8dd64d01a418aed03903292e5c84e731e737"
        }
      },
      "graphviz-dot": {
        "kind": "graphviz",
        "version": "dot - graphviz version 14.1.2 (0)",
        "file_sha256": {
          "${REPO}/.tools-shell/native/bin/dot": "a0248824fe9f3e3d1d13486d8f3f4fa6bcd44f1b210e945cf41f25bffed4795c"
        },
        "environment_overrides": {
          "XDG_CACHE_HOME": "${REPO}/.tools/cache/xdg"
        },
        "provenance": {
          "runtime_lock_sha256": "7748932cce1f5d830f3810c4eac1fee560608db395925bc13f563704ef4c1cf1",
          "setup_platform": "osx-arm64",
          "source": "https://graphviz.org/",
          "version": "14.1.2",
          "binary_sha256": "a0248824fe9f3e3d1d13486d8f3f4fa6bcd44f1b210e945cf41f25bffed4795c",
          "native_lock_sha256": "c9d840c2093e74cfa432ccc92a5168145df6ad4efb5397b798a34d7960fc864e",
          "png_backend": "cairo",
          "svg_backend": "svg"
        }
      },
      "plantuml-dot": {
        "kind": "plantuml",
        "version": "PlantUML version 1.2026.8 / 149874a [2026-09-05 15:59:17 UTC]\n(GPL source distribution)\n\nBuild Version: 1.2026.8\nGit Commit: 149874a\nCompile Time: 2026-09-05 15:59:17 UTC\n\nJava Runtime: OpenJDK Runtime Environment\nJVM: OpenJDK 64-Bit Server VM\nDefault Encoding: UTF-8\nLanguage: en\nCountry: US\n \nPLANTUML_LIMIT_SIZE: 4096\n\nGraphViz: dot - graphviz version 14.1.2 (0)\nInstallation seems OK. File generation OK",
        "file_sha256": {
          "${REPO}/.tools-shell/native/lib/jvm/bin/java": "ec64ac719290ad080c7f8a4f5d83402e4152f98f486fe14150cf734a46ebcbb1",
          "${REPO}/.tools-shell/plantuml.jar": "5e1ecfa8ecd32c90b03bbf3b1eb6f020943f98ab0fcf4032be31a0002ee2c462",
          "${REPO}/.tools-shell/native/bin/dot": "a0248824fe9f3e3d1d13486d8f3f4fa6bcd44f1b210e945cf41f25bffed4795c"
        },
        "environment_overrides": {
          "GRAPHVIZ_DOT": "${REPO}/.tools-shell/native/bin/dot",
          "JAVA_HOME": "${REPO}/.tools-shell/native/lib/jvm",
          "XDG_CACHE_HOME": "${REPO}/.tools/cache/xdg"
        },
        "provenance": {
          "runtime_lock_sha256": "7748932cce1f5d830f3810c4eac1fee560608db395925bc13f563704ef4c1cf1",
          "setup_platform": "osx-arm64",
          "source": "https://plantuml.com/",
          "version": "1.2026.8",
          "jar_sha256": "5e1ecfa8ecd32c90b03bbf3b1eb6f020943f98ab0fcf4032be31a0002ee2c462",
          "java": "21.0.10",
          "graphviz": "14.1.2"
        }
      }
    }
  },
  "provenance": {},
  "harness_sha256": {
    "benchmarks/__init__.py": "3f12f303f54ccde662189b4562687bec662939c73bd9fb6022b0c29fa7161ac1",
    "benchmarks/__main__.py": "545e40a168a3e07ca69e608a71a8c94d008397f4d2b003625f7593e8f248b3d1",
    "benchmarks/corpus.py": "b17db6de939a4db3e86f4b9de8039d30b6cb253397ec3b5d79d523c5f2516597",
    "benchmarks/report.py": "2cebe0568134bdb084584e94ae4c575b37ad91317bdc40d129ca60ff0b73e728",
    "benchmarks/runner.py": "fdfb6fa70e2483325147e0847b8c9e0d83ebab02ce78621eb9d225e1cc532a77",
    "benchmarks/svg_validation.py": "7b6065c196ab2095977ec26bea43f0bd8266431e38ddb229dad522ac6b90b301"
  },
  "source_hashes": {
    "run.json": "591688568998229cba8789b4ae23c0a852beddfb353919cfd0cf3c660e73951d",
    "raw.jsonl": "09463b1536ab4388ccd2da683ae76c3d43d47950d1612dda260455302faeaf78",
    "inputs/manifest.json": "bf2caf3b292397a431d03c4a8468d473d94973d985cd0d9a620cd337c6431a21"
  },
  "corpus_validation": {
    "schema_version": 1,
    "valid": true,
    "errors": [],
    "fixtures": [
      {
        "id": "fulcro_rad",
        "counts": {
          "leaf_nodes": 19,
          "groups": 6,
          "edges": 16
        },
        "source_audits": {
          "mermaid": {
            "objects": 25,
            "edges": 16,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 25,
            "edges": 16,
            "synthetic_nodes": 6
          },
          "plantuml": {
            "objects": 25,
            "edges": 16,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "jupyter_aws_eks",
        "counts": {
          "leaf_nodes": 12,
          "groups": 12,
          "edges": 4
        },
        "source_audits": {
          "mermaid": {
            "objects": 24,
            "edges": 4,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 24,
            "edges": 4,
            "synthetic_nodes": 1
          },
          "plantuml": {
            "objects": 24,
            "edges": 4,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "jupyter_k8s_oidc",
        "counts": {
          "leaf_nodes": 23,
          "groups": 10,
          "edges": 17
        },
        "source_audits": {
          "mermaid": {
            "objects": 33,
            "edges": 17,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 33,
            "edges": 17,
            "synthetic_nodes": 0
          },
          "plantuml": {
            "objects": 33,
            "edges": 17,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "leios_simulator",
        "counts": {
          "leaf_nodes": 20,
          "groups": 5,
          "edges": 18
        },
        "source_audits": {
          "mermaid": {
            "objects": 25,
            "edges": 18,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 25,
            "edges": 18,
            "synthetic_nodes": 5
          },
          "plantuml": {
            "objects": 25,
            "edges": 18,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "lion_reader_frontend",
        "counts": {
          "leaf_nodes": 19,
          "groups": 7,
          "edges": 16
        },
        "source_audits": {
          "mermaid": {
            "objects": 26,
            "edges": 16,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 26,
            "edges": 16,
            "synthetic_nodes": 2
          },
          "plantuml": {
            "objects": 26,
            "edges": 16,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "mocha_soc",
        "counts": {
          "leaf_nodes": 34,
          "groups": 4,
          "edges": 18
        },
        "source_audits": {
          "mermaid": {
            "objects": 38,
            "edges": 18,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 38,
            "edges": 18,
            "synthetic_nodes": 3
          },
          "plantuml": {
            "objects": 38,
            "edges": 18,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "queue_workers",
        "counts": {
          "leaf_nodes": 23,
          "groups": 10,
          "edges": 23
        },
        "source_audits": {
          "mermaid": {
            "objects": 33,
            "edges": 23,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 33,
            "edges": 23,
            "synthetic_nodes": 0
          },
          "plantuml": {
            "objects": 33,
            "edges": 23,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "ross_overview",
        "counts": {
          "leaf_nodes": 24,
          "groups": 3,
          "edges": 14
        },
        "source_audits": {
          "mermaid": {
            "objects": 27,
            "edges": 14,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 27,
            "edges": 14,
            "synthetic_nodes": 2
          },
          "plantuml": {
            "objects": 27,
            "edges": 14,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "spyre_encoder",
        "counts": {
          "leaf_nodes": 32,
          "groups": 35,
          "edges": 6
        },
        "source_audits": {
          "mermaid": {
            "objects": 67,
            "edges": 6,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 67,
            "edges": 6,
            "synthetic_nodes": 6
          },
          "plantuml": {
            "objects": 67,
            "edges": 6,
            "synthetic_nodes": 0
          }
        }
      },
      {
        "id": "tpmjs_architecture",
        "counts": {
          "leaf_nodes": 140,
          "groups": 48,
          "edges": 63
        },
        "source_audits": {
          "mermaid": {
            "objects": 188,
            "edges": 63,
            "synthetic_nodes": 0
          },
          "graphviz": {
            "objects": 188,
            "edges": 63,
            "synthetic_nodes": 30
          },
          "plantuml": {
            "objects": 188,
            "edges": 63,
            "synthetic_nodes": 0
          }
        }
      }
    ],
    "totals": {
      "leaf_nodes": 346,
      "groups": 140,
      "edges": 195
    },
    "network_required": false
  }
}
```
