Open index.html in a local browser. report.md, summary.csv, and summary.json summarize raw.jsonl.
Inputs and rendered assets retain their original bytes and hashes. run.json records the source revision and publication transformations.
Path tokens, when present, replace only explicitly selected host path prefixes. They are not executable filesystem paths.
To repeat the experiment, check out the captured benchmark repository revision, run scripts/setup.py, and use the settings recorded in run.json.
This is one machine/session; see its environment and the repository methodology before interpreting ratios.
